from django.shortcuts import render,redirect, get_object_or_404
from app1.forms import CustomUserForm
from .forms import CustomUserForm, ChildForm,CaretakerForm
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from .models import Child, Caretaker



# Create your views here.

def home(request):
  return render(request,"app1/index.htm")
  
def login_page(request):
  if request.user.is_authenticated:
    return redirect("/")
  else:
    if request.method=='POST':
      name=request.POST.get('username')
      pwd=request.POST.get('password')
      user=authenticate(request,username=name,password=pwd)
      if user is not None:
        login(request,user)
        messages.success(request,"Logged in Successfully")
        return redirect("/")
      else:
        messages.error(request,"Invalid User Name or Password")
        return redirect("/login")
    return render(request,"app1/login.htm")
 
def logout_page(request):
  if request.user.is_authenticated:
    logout(request)
    messages.success(request,"Logged out Successfully")
  return redirect("/")

def register(request):
  form=CustomUserForm()
  if request.method=='POST':
    form=CustomUserForm(request.POST)
    if form.is_valid():
      form.save()
      messages.success(request,"Registration Success You can Login Now..!")
      return redirect('/login')
  return render(request,"app1/register.htm",{'form':form})


def child_list(request):
    children = Child.objects.all()
    return render(request, 'app1/child_list.html', {'children': children})

def child_create(request):
    if request.method == 'POST':
        form = ChildForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('child_list')
    else:
        form = ChildForm()
    return render(request, 'app1/child_form.html', {'form': form})

def child_update(request, pk):
    child = get_object_or_404(Child, pk=pk)
    if request.method == 'POST':
        form = ChildForm(request.POST, instance=child)
        if form.is_valid():
            form.save()
            return redirect('child_list')
    else:
        form = ChildForm(instance=child)
    return render(request, 'app1/child_form.html', {'form': form})

def child_delete(request, pk):
    child = get_object_or_404(Child, pk=pk)
    if request.method == 'POST':
        child.delete()
        return redirect('child_list')
    return render(request, 'app1/child_confirm_delete.html', {'child': child})

def add_caretaker(request):
    if request.method == "POST":
        form = CaretakerForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Caretaker added successfully!")
            return redirect('caretaker_list')  # Redirect to the list of caretakers after successful addition
    else:
        form = CaretakerForm()

    return render(request, 'app1/add_caretaker.html', {'form': form})


def caretaker_list(request):
    caretakers = Caretaker.objects.all()
    return render(request, 'app1/caretaker_list.html', {'caretakers': caretakers})

def caretaker_update(request, pk):
    caretaker = get_object_or_404(Caretaker, pk=pk)
    if request.method == "POST":
        form = CaretakerForm(request.POST, instance=caretaker)
        if form.is_valid():
            form.save()
            messages.success(request, "Caretaker updated successfully!")
            return redirect('caretaker_list')
    else:
        form = CaretakerForm(instance=caretaker)
    
    return render(request, 'app1/edit_caretaker.html', {'form': form})

def caretaker_delete(request, pk):
    caretaker = get_object_or_404(Caretaker, pk=pk)
    if request.method == "POST":
        caretaker.delete()
        messages.success(request, "Caretaker deleted successfully!")
        return redirect('caretaker_list')

    return render(request, 'app1/delete_caretaker.html', {'caretaker': caretaker})