from django.urls import path
from . import views
urlpatterns=[
     path("",views.home,name="home"),
     path("register",views.register,name="register"),
     path('login',views.login_page,name="login"),
     path('logout',views.logout_page,name="logout"),
     path('child_view', views.child_list, name='child_list'),
    path('new', views.child_create, name='child_create'),
    path('edit/<int:pk>', views.child_update, name='child_update'),
    path('delete/<int:pk>', views.child_delete, name='child_delete'),
     path("add_caretaker", views.add_caretaker, name="add_caretaker"),
     path('caretakers/', views.caretaker_list, name='caretaker_list'),
    path('caretaker/edit/<int:pk>/', views.caretaker_update, name='caretaker_update'),
    path('caretaker/delete/<int:pk>/', views.caretaker_delete, name='caretaker_delete'),


]
