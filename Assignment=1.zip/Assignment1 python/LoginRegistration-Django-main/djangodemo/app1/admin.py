from django.contrib import admin
from .models import Caretaker,Child

# Register your models here.
admin.site.register(Caretaker)
admin.site.register(Child)